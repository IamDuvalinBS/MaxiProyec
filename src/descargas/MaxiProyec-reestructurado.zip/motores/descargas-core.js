import axios from "axios";
import { execFile } from "child_process";
import { promisify } from "util";
import fs from "fs";
import os from "os";
import path from "path";

const execFileAsync = promisify(execFile);

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
};

export const LIMITE_VIDEO_WHATSAPP_MB = 60;

const PERFILES_H264_OK = new Set(["Baseline", "Constrained Baseline", "Main", "High"]);

async function analizarPistas(rutaArchivo) {
  try {
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "error",
      "-print_format", "json",
      "-show_streams",
      rutaArchivo
    ]);
    const data = JSON.parse(stdout);
    const video = data.streams?.find((s) => s.codec_type === "video") || null;
    const audio = data.streams?.find((s) => s.codec_type === "audio") || null;
    return { video, audio };
  } catch (e) {
    console.log(`[descargas-core] No pude analizar el archivo con ffprobe: ${e.message}`);
    return { video: null, audio: null };
  }
}

function videoYaCompatible(video, audio) {
  if (!video || !audio) return false;
  if (video.codec_name !== "h264") return false;
  if (video.pix_fmt !== "yuv420p") return false;
  if (video.profile && !PERFILES_H264_OK.has(video.profile)) return false;
  if (audio.codec_name !== "aac") return false;
  return true;
}

export async function descargarBuffer(url) {
  const { data } = await axios.get(url, {
    responseType: "arraybuffer",
    headers: HEADERS,
    timeout: 30000,
    maxContentLength: 100 * 1024 * 1024
  });
  return Buffer.from(data);
}

export async function asegurarVideoCompatibleWhatsApp(bufferEntrada) {
  const tmp = os.tmpdir();
  const sufijo = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const entrada = path.join(tmp, `dc_in_${sufijo}.mp4`);
  const salida = path.join(tmp, `dc_out_${sufijo}.mp4`);

  fs.writeFileSync(entrada, bufferEntrada);

  try {
    const { video, audio } = await analizarPistas(entrada);

    if (videoYaCompatible(video, audio)) {
      try {
        await execFileAsync("ffmpeg", ["-y", "-i", entrada, "-c", "copy", "-movflags", "+faststart", salida]);
        console.log("[descargas-core] Video ya era compatible, se remuxeo sin re-codificar");
        return fs.readFileSync(salida);
      } catch (e) {
        console.log(`[descargas-core] Remux rapido fallo, se re-codifica completo: ${e.message}`);
      }
    }

    await execFileAsync("ffmpeg", [
      "-y",
      "-i", entrada,
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-profile:v", "baseline",
      "-level", "3.0",
      "-pix_fmt", "yuv420p",
      "-c:a", "aac",
      "-b:a", "128k",
      "-movflags", "+faststart",
      salida
    ]);
    return fs.readFileSync(salida);
  } finally {
    if (fs.existsSync(entrada)) fs.unlinkSync(entrada);
    if (fs.existsSync(salida)) fs.unlinkSync(salida);
  }
}

export async function combinarVideoAudioWhatsApp(bufferVideo, bufferAudio) {
  const tmp = os.tmpdir();
  const sufijo = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const entradaVideo = path.join(tmp, `dv_in_${sufijo}.mp4`);
  const entradaAudio = path.join(tmp, `da_in_${sufijo}.m4a`);
  const salida = path.join(tmp, `dv_out_${sufijo}.mp4`);

  fs.writeFileSync(entradaVideo, bufferVideo);
  fs.writeFileSync(entradaAudio, bufferAudio);

  try {
    await execFileAsync("ffmpeg", [
      "-y",
      "-i", entradaVideo,
      "-i", entradaAudio,
      "-map", "0:v:0",
      "-map", "1:a:0",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-profile:v", "baseline",
      "-level", "3.0",
      "-pix_fmt", "yuv420p",
      "-c:a", "aac",
      "-b:a", "128k",
      "-movflags", "+faststart",
      "-shortest",
      salida
    ]);
    return fs.readFileSync(salida);
  } finally {
    if (fs.existsSync(entradaVideo)) fs.unlinkSync(entradaVideo);
    if (fs.existsSync(entradaAudio)) fs.unlinkSync(entradaAudio);
    if (fs.existsSync(salida)) fs.unlinkSync(salida);
  }
}

export async function consultarApiDescarga(apiUrl, link, paramNombre = "url") {
  const { data } = await axios.get(apiUrl, {
    params: { [paramNombre]: link },
    headers: HEADERS,
    timeout: 20000
  });

  if (!data || data.status === false) {
    throw new Error(data?.message || `La API ${apiUrl} no devolvió un resultado válido.`);
  }
  return data;
}

export function extraerEnlaceDescarga(json) {
  const candidatos = [
    json?.result?.url,
    json?.result?.download,
    json?.result?.download_url,
    json?.result?.dl,
    json?.result?.link,
    json?.data?.url,
    json?.data?.download,
    json?.url,
    json?.download,
    json?.link
  ];
  const enlace = candidatos.find(Boolean);
  if (!enlace) throw new Error("No encontré el enlace de descarga en la respuesta de la API.");
  return enlace;
}

export async function asegurarAudioCompatibleWhatsApp(bufferEntrada) {
  const tmp = os.tmpdir();
  const sufijo = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const entrada = path.join(tmp, `da_in_${sufijo}`);

  fs.writeFileSync(entrada, bufferEntrada);

  try {
    const { audio } = await analizarPistas(entrada);

    if (audio?.codec_name === "mp3") {
      console.log("[descargas-core] Audio ya era mp3, se devuelve sin reencodear");
      return bufferEntrada;
    }

    const salida = path.join(tmp, `da_out_${sufijo}.mp3`);
    try {
      await execFileAsync("ffmpeg", ["-y", "-i", entrada, "-c:a", "libmp3lame", "-b:a", "192k", salida]);
      return fs.readFileSync(salida);
    } finally {
      if (fs.existsSync(salida)) fs.unlinkSync(salida);
    }
  } finally {
    if (fs.existsSync(entrada)) fs.unlinkSync(entrada);
  }
}

export async function asegurarImagenCompatibleWhatsApp(bufferEntrada) {
  const tmp = os.tmpdir();
  const sufijo = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const entrada = path.join(tmp, `di_in_${sufijo}`);
  const salida = path.join(tmp, `di_out_${sufijo}.jpg`);

  fs.writeFileSync(entrada, bufferEntrada);

  try {
    await execFileAsync("ffmpeg", [
      "-y",
      "-i", entrada,
      "-q:v", "2",
      "-pix_fmt", "yuvj420p",
      salida
    ]);
    return fs.readFileSync(salida);
  } finally {
    if (fs.existsSync(entrada)) fs.unlinkSync(entrada);
    if (fs.existsSync(salida)) fs.unlinkSync(salida);
  }
}

